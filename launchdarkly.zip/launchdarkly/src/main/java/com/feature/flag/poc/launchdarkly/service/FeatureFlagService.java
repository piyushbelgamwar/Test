package com.feature.flag.poc.launchdarkly.service;

import com.launchdarkly.sdk.LDValue;

public interface FeatureFlagService {

    boolean isEnabled(String flagKey);

    /**
     * String flag variation
     */
    String getString(String flagKey, String defaultValue);

    /**
     * Integer flag variation
     */
    int getInt(String flagKey, int defaultValue);

    /**
     * Double flag variation
     */
    double getDouble(String flagKey, double defaultValue);

    /**
     * JSON flag variation as LDValue
     */
    LDValue getJson(String flagKey, LDValue defaultValue);

    boolean isFeatureEnabled(String flagKey);
}
