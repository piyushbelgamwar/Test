package com.feature.flag.poc.launchdarkly.autoconfig;

import com.feature.flag.poc.launchdarkly.config.FeatureFlagProperties;
import com.feature.flag.poc.launchdarkly.service.DefaultFeatureFlagService;
import com.feature.flag.poc.launchdarkly.service.FeatureFlagService;
import com.launchdarkly.sdk.server.LDClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.util.Arrays;
import java.util.Map;

@Configuration
@EnableConfigurationProperties(FeatureFlagProperties.class)
public class FeatureFlagAutoConfiguration {
    @Autowired
    private Environment environment;

    @Bean(destroyMethod = "close")
    @ConditionalOnMissingBean
    public LDClient ldClient(FeatureFlagProperties props,
                             Environment env /* ← Spring injects this */) {
        String profile = Arrays.stream(env.getActiveProfiles())
                .findFirst().orElse("default");
        Map<String,String> keys = props.getSdkKeys();
        String sdkKey = keys.getOrDefault(profile, keys.get("default"));
        if (sdkKey == null || sdkKey.isBlank()) {
            throw new IllegalStateException(
                    "No LaunchDarkly SDK key for profile '" + profile + "'");
        }
        return new LDClient(sdkKey);
    }

    @Bean
    @ConditionalOnMissingBean(FeatureFlagService.class)
    public FeatureFlagService featureFlagService(LDClient ldClient) {
        return new DefaultFeatureFlagService(ldClient);
    }
}
