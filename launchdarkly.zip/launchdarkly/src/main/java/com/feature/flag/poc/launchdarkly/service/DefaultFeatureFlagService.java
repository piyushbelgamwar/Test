package com.feature.flag.poc.launchdarkly.service;

import com.launchdarkly.sdk.LDContext;
import com.launchdarkly.sdk.LDValue;
import com.launchdarkly.sdk.server.LDClient;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

public class DefaultFeatureFlagService implements FeatureFlagService {

    private final LDClient ldClient;
    private final LDContext context;
    private final ConcurrentHashMap<String,Boolean> cache = new ConcurrentHashMap<>();
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

    public DefaultFeatureFlagService(LDClient ldClient) {
        this.ldClient = ldClient;
        this.context = LDContext.builder("feature-flag-client").anonymous(true).build();
    }

    @Override
    public boolean isEnabled(String flagKey) {
        Boolean cachedValue = cache.get(flagKey);
        if (cachedValue != null) {
            return cachedValue;
        }
        try {
            // Fetch from LaunchDarkly SDK (global boolean flags)
            boolean enabled = ldClient.boolVariation(flagKey, context,false);
            // Cache for subsequent calls
            cache.put(flagKey, enabled);
            return enabled;
        } catch (Exception e) {
            // On errors, fallback to last cached or default false
            return cache.getOrDefault(flagKey, false);
        }
    }
    @Override
    public String getString(String flagKey, String defaultValue) {
        try {
            return ldClient.stringVariation(flagKey, context, defaultValue);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    @Override
    public int getInt(String flagKey, int defaultValue) {
        try {
            return ldClient.intVariation(flagKey, context, defaultValue);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    @Override
    public double getDouble(String flagKey, double defaultValue) {
        try {
            return ldClient.doubleVariation(flagKey, context, defaultValue);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    @Override
    public LDValue getJson(String flagKey, LDValue defaultValue) {
        try {
            return ldClient.jsonValueVariation(flagKey, context, defaultValue);
        } catch (Exception e) {
            return defaultValue;
        }
    }
    @Override
    public boolean isFeatureEnabled(String flagKey) {
        String flagValue = getString(flagKey, null);
        if (flagValue == null) {
            return false;
        }
        try {
            Date targetDate = dateFormat.parse(flagValue);
            return new Date().compareTo(targetDate) >= 0;
        } catch (Exception e) {
            return false;
        }
    }
}

