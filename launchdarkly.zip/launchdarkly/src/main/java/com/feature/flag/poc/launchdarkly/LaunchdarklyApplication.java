package com.feature.flag.poc.launchdarkly;

import com.feature.flag.poc.launchdarkly.service.FeatureFlagService;
import com.launchdarkly.sdk.LDValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaunchdarklyApplication implements CommandLineRunner {


	@Autowired
	private FeatureFlagService featureFlagService;

	public static void main(String[] args) {
		SpringApplication.run(LaunchdarklyApplication.class, args);
	}

	@Override
	public void run(String... args) {
		String flagKey = "bug-reg-1204";
		boolean enabled = featureFlagService.isEnabled(flagKey);
		System.out.println("[Feature Flag] '" + flagKey + "' is " + (enabled ? "ENABLED" : "DISABLED"));

		// Fetch other types
		String welcome = featureFlagService.getString("bug-reg-1205", "Hi");
		//int limit = featureFlagService.getInt("max-items", 5);
		double ratio = featureFlagService.getDouble("bug-reg-1206", 0.75);
		LDValue featureConfig = featureFlagService.getJson("reg-1207", LDValue.ofNull());
		boolean fromDate = featureFlagService.isFeatureEnabled("bug-reg-1208");

		System.out.println("Welcome message: " + welcome);
		//System.out.println("Max items: " + limit);
		System.out.println("Threshold: " + ratio);
		System.out.println("Feature Config JSON: " + featureConfig);
		System.out.println("fromDate: " + fromDate);
	}
}
