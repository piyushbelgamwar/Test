package com.feature.flag.poc.launchdarkly.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.HashMap;
import java.util.Map;

@ConfigurationProperties(prefix = "launchdarkly")
public class FeatureFlagProperties {

    private Map<String, String> sdkKeys = new HashMap<>();

    public Map<String, String> getSdkKeys() {
        return sdkKeys;
    }

    public void setSdkKeys(Map<String, String> sdkKeys) {
        // guard against null binding
        this.sdkKeys = (sdkKeys != null ? sdkKeys : new HashMap<>());
    }
}
