package com.feature.flag.poc.launchdarkly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaunchdarklyApplicationTests {

	@Test
	void contextLoads() {
	}

}
